clear;clc;
addpath(genpath(pwd));

dataset = {'MSRC-v1'};
alpha1 = 1;alpha2 = 0.01;
beta1 = 0.01;beta2 = 0.1;

dataname = char(dataset);
load(dataname);
gt = truelabel{1}';X = data;    
cls_num = length(unique(gt));

S = JLLSD(X,alpha1,alpha2,beta1,beta2,dataname);
C = SpectralClustering(S,cls_num);
[ACC, NMI] = AccNmiPurity(gt, C);
[ARI]=RandIndex(gt,C);
[F, Precision, Recall] = compute_f(gt,C);

fprintf("ACC=%.3f NMI=%.3f, ARI=%.3f, F=%.3f, Precision=%.3f, Recall=%.3f\n",ACC,NMI,ARI,F,Precision,Recall);
