function [S,iter,K] =JLLSD(X,alpha1,alpha2,beta1,beta2,dataname)

K = length(X); N = size(X{1},2); 
for v=1:K
    [X{v}]=NormalizeData(X{v}); 
end
% 初始化
for k=1:K
    C{k} = zeros(N,N); 
    W{k} = zeros(N,N);
    G{k} = zeros(N,N);
    J{k} = zeros(N,N);
    D{k} = zeros(N,N);
    H{k} = zeros(N,N);
    E{k} = zeros(size(X{k},1),N);
    Y1{k} = zeros(size(X{k},1),N);
    Y2{k} = zeros(N,N);
    Y3{k} = zeros(N,N);
    Y4{k} = zeros(N,N);
    Y5{k} = zeros(N,N);
end
y2 = zeros(N*N*K,1);
g = zeros(N*N*K,1);
dim1 = N;dim2 = N;dim3 = K;
myNorm = 'tSVD_1';
sX = [N, N, K]; 

% for the TV norm
param2.verbose=1;
param2.max_iter=10;
param2.verbose = 0;

Isconverg = 0;epson = 1e-7; 
iter = 0;
mu = 10e-3; max_mu = 10e10; pho_mu = 2;
for k = 1:K
    Xt{k} = X{k}'*X{k};
end


while(Isconverg == 0)

    for k=1:K
        %update C/D
        tmp1 = mu*X{k}'*(X{k}-X{k}*D{k}-E{k}+Y1{k}/mu)+(mu*G{k}-Y2{k})+(mu*J{k}-Y3{k});
        C{k} = inv(mu*Xt{k}+(mu+mu)*eye(N,N))*tmp1;
        tmp2 = mu*X{k}'*(X{k}-X{k}*C{k}-E{k}+Y1{k}/mu)+(mu*W{k}-Y4{k})+(mu*H{k}-Y5{k});
        D{k} = inv(mu*Xt{k}+(mu+mu)*eye(N,N))*tmp2;
       
        %update E
        F = [];
        for v = 1:K
            F = [F; X{v}-X{v}*(C{v}+D{v})+Y1{v}/mu];
        end
        [Econcat] = solve_l1l2(F,1/mu);
        e_start = 1; e_end = 0;
        for v = 1:K
            e_end = e_end + size(X{v},1);
            E{v} = Econcat(e_start:e_end, :);
            e_start = e_start + size(X{v},1);
        end
      
        %update Y1,3,4,5
        Y1{k} = Y1{k}+mu*(X{k}-X{k}*(D{k}+C{k})-E{k});
        Y3{k} = Y3{k}+mu*(C{k}-J{k});
        Y4{k} = Y4{k}+mu*(D{k}-W{k});
        Y5{k} = Y5{k}+mu*(D{k}-H{k});    
        
        %update W/H 
        W{k} = solve_l1l2(D{k}+Y4{k}/mu,beta1/mu);
        H{k} = upH(D{k}+Y5{k}/mu, 2*beta2/mu);
        
    end
    
    %update G
    C_tensor = cat(3, C{:,:});
    Y2_tensor = cat(3, Y2{:,:}); 
    c = C_tensor(:);
    y2 = Y2_tensor(:);
    [g, objV] = wshrinkObj(c + 1/mu*y2,1/mu*alpha1,sX,0,3); 
    G_tensor = reshape(g, sX); 
    
    %update Y2
    y2 = y2 + mu*(c - g);
    
    %updata J
    for k = 1:K
        temp = C{k} + Y3{k}/mu;
        J{k} = prox_TV(temp,alpha2/mu,param2);     
    end
    history.objval(iter+1)   =  objV;
    
    %%coverge condition
    Isconverg = 1; 
    for k=1:K
        if (norm(X{k}-X{k}*(D{k}+C{k})-E{k},inf)>epson)
            history.norm_Z = norm(X{k}-X{k}*(D{k}+C{k})-E{k},inf); 
            Isconverg = 0;
        end
        
        G{k} = G_tensor(:,:,k); 
        Y2_tensor = reshape(y2, sX);
        Y2{k} = Y2_tensor(:,:,k);
        if (norm(C{k}-G{k},inf)>epson)
            history.norm_Z_G = norm(C{k}-G{k},inf);
            Isconverg = 0;
        end
        if (norm(C{k}-J{k},inf)>epson)
            history.norm_Z_J = norm(C{k}-J{k},inf);
            Isconverg = 0;
        end
    
        if (norm(D{k}-W{k},inf)>epson)
            history.norm_D_W = norm(D{k}-W{k},inf);
            Isconverg = 0;
        end
        
        if (norm(D{k}-H{k},inf)>epson)
            history.norm_D_H = norm(D{k}-H{k},inf);
            Isconverg = 0;
        end
    end
   
    if (iter>200)
        Isconverg  = 1;
    end
    iter = iter + 1;
    
    mu = min(mu*pho_mu, max_mu);
end

S = 0;
for k=1:K
    S = S + abs(C{k}+D{k})+abs(C{k}'+D{k}');
end
S=S/(2*K);
end


